import { useState } from "react";
import "./App.css";
import Drawer from "@material-ui/core/Drawer";
import Divider from "@material-ui/core/Divider";
import {
  makeStyles,
  useTheme,
  Theme,
  createStyles,
} from "@material-ui/core/styles";
import { Box, Button } from "@material-ui/core";
import PhotoCropper from "./components/PhotoCropper";
import Drag from "./components/Drag";
import Container from "./dragndrop/Container";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

const drawerWidth = "70%";

const useStyles = makeStyles((theme: Theme) =>
  createStyles({
    root: {
      display: "flex",
    },
    drawer: {
      width: drawerWidth,
      flexShrink: 0,
    },
    drawerPaper: {
      width: drawerWidth,
    },
    drawerHeader: {
      display: "flex",
      alignItems: "center",
      padding: theme.spacing(0, 1),
      ...theme.mixins.toolbar,
      justifyContent: "flex-start",
    },
  })
);

function App() {
  const classes = useStyles();
  const theme = useTheme();
  const [open, setOpen] = useState(false);
  const handleDrawerOpen = () => {
    setOpen(!open);
  };

  return (
    <div className="App">
      <h1>react-cropper | working demo</h1>
      <Button onClick={handleDrawerOpen}>Open Drawer</Button>
      {/* <Drag /> */}
      <DndProvider backend={HTML5Backend}>
        <Container />
      </DndProvider>
      <Drawer
        className={classes.drawer}
        variant="persistent"
        anchor="right"
        open={open}
        classes={{
          paper: classes.drawerPaper,
        }}
      >
        <div className={classes.drawerHeader}>Photo</div>
        <Divider />
        <Box>
          <button>Upload an Image</button>
          <PhotoCropper />
        </Box>
      </Drawer>
    </div>
  );
}

export default App;
