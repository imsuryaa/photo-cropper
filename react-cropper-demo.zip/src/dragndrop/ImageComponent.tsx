import React, { useState } from 'react'
import './styles.css'

interface ImageProps {
    id: number;
    text: string;
}

const ImageComponent = ({id, text}: ImageProps) => {
    const [open, setOpen] = useState(false)
    const viewImage = () => {
        return (
            <div>View Image</div>
        )
    }
    const handleClick = () => {
        setOpen(!open)
    }
  return (
    <div className=''>
        <img src={text} style={{width: "100%"}}/>
        <button onClick={handleClick}>Edit</button>
        {open ? viewImage() : ''}
    </div>
  )
}

export default ImageComponent