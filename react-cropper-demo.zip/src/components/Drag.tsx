import React, { useRef, useState } from "react";
import "./styles.css";

const Drag = () => {
  const imgObj = [
    {
      id: 1,
      src: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80",
    },
    {
      id: 2,
      src: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 3,
      src: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 4,
      src: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 5,
      src: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 6,
      src: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 7,
      src: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80",
    },
    {
      id: 8,
      src: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1332&q=80",
    },
    {
      id: 9,
      src: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 10,
      src: "https://images.unsplash.com/photo-1599809275671-b5942cabc7a2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
  ];

  const [list, setList] = useState(imgObj);
  const [dragging, setDragging] = useState(false);

  const dragItem: any = useRef();
  const dragItemNode: any = useRef();

  const handletDragStart = (e: any, item: any) => {
    console.log("Starting to drag", item);

    dragItemNode.current = e.target;
    dragItemNode.current!.addEventListener("dragend", handleDragEnd);
    dragItem.current = item;

    setTimeout(() => {
      setDragging(true);
    }, 0);
  };

  const handleDragEnter = (e: any, targetItem: any) => {
    console.log("Entering a drag target", targetItem);
    if (dragItemNode.current !== e.target) {
      console.log("Target is NOT the same as dragged item");
      setList((oldList) => {
        console.log("old list ------", oldList)
        let newList = JSON.parse(JSON.stringify(oldList));
        // newList[targetItem].items.splice(targetItem.itemI, 0, newList[dragItem.current].items.splice(dragItem.current.itemI,1)[0])
        newList.splice(targetItem, 0, newList.splice(dragItem.current,1)[0])
        console.log('splice data---', newList.splice(targetItem, 0, newList[dragItem.current]))
        console.log('newList------',newList)
        dragItem.current = targetItem;
        localStorage.setItem('List', JSON.stringify(newList));
        return newList;
      });
    }
  };

  const handleDragEnd = (e: any) => {
    if (dragging) {
      setDragging(false);
      dragItem.current = null;
      dragItemNode.current!.removeEventListener("dragend", handleDragEnd);
      dragItemNode.current = null;
    }
  };

  return (
    <div className="container">
      <div className="images-list">
        {list.map((img, index) => (
          <img
            src={img.src}
            style={{ width: "10%" }}
            draggable
            onDragStart={(e) => handletDragStart(e, index)}
            onDragEnter={(e) => handleDragEnter(e, index)}
          />
        ))}
      </div>
    </div>
  );
};

export default Drag;
