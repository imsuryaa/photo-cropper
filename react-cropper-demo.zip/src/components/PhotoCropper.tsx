import React, { useEffect, useRef, useState } from "react";
import { Cropper } from "react-cropper";
import "cropperjs/dist/cropper.css";
import { Button, Divider, Tooltip } from "@material-ui/core";
import "./styles.css";


const PhotoCropper = () => {
  const imgSrc =
    "https://images.unsplash.com/photo-1566908829550-e6551b00979b?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8M3x8bWFuc2lvbnxlbnwwfHwwfHw%3D&w=1000&q=80";

  const imgObj = [
    {
      id: 1,
      src: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80",
    },
    {
      id: 2,
      src: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 3,
      src: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 4,
      src: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 5,
      src: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 6,
      src: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 7,
      src: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80",
    },
    {
      id: 8,
      src: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1332&q=80",
    },
    {
      id: 9,
      src: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 10,
      src: "https://images.unsplash.com/photo-1599809275671-b5942cabc7a2?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 11,
      src: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1074&q=80",
    },
    {
      id: 12,
      src: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 13,
      src: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 14,
      src: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
    {
      id: 15,
      src: "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
    },
  ];

  const cropperRef = useRef(null);
  const [image, setImage] = useState("");
  const [cropData, setCropData] = useState("#");
  const [cropper, setCropper] = useState<Cropper>();
  // const [aspectRatio, setAspectRatio] = useState(16/9)
  const [crop, setCrop] = useState(false);
  const [editId, setEditId] = useState(0);
  const [active, setActive] = useState(false);
  const [display, setDisplay] = useState(false);
  const [screenRatio, setScreenratio] = useState(2 / 3);
  const [editCap, setEditCap] = useState(false);
  const [select, setSelect] = useState(0);

  const landscapeClick = () => {
    cropper?.setAspectRatio(16 / 9);
  };

  const potraitClick = () => {
    cropper?.setAspectRatio(2 / 3);
  };

  const getCropData = () => {
    if (typeof cropper !== "undefined") {
      setCropData(cropper.getCroppedCanvas().toDataURL());
      //   console.log(cropper.getCroppedCanvas().toDataURL());
    }
    setEditId(0);
    setDisplay(false);
  };

  const onDownload = () => {
    if (typeof cropper !== "undefined") {
      const data = cropper.getCroppedCanvas();
      data.toBlob((blob: any) => {
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = "Cropped-Image.jpg";
        a.click();
        URL.revokeObjectURL(url);
      });
      //   console.log(data.toBlob);
    }
    // console.log(cropperRef.current?.cropper)
  };

  const makeFullScreen = () => {
    const divObj = document.getElementById("theImage");
    if (divObj?.requestFullscreen) {
      divObj.requestFullscreen();
    } else {
      console.log("Fullscreen API is not supported");
    }
  };

  const onImageClick = (id: number, src: string) => {
    setEditId(id);
    setImage(src);
    setSelect(id);
  };

  const cropperTool = () => (
    <div>
      <Cropper
        style={{
          height: 400,
          width: "40vw",
          marginLeft: "auto",
          marginRight: "auto",
        }}
        zoomable={false}
        preview=".img-preview"
        src={image}
        initialAspectRatio={screenRatio}
        viewMode={2}
        guides={false}
        minCropBoxHeight={300}
        minCropBoxWidth={200}
        background={false}
        responsive={true}
        autoCropArea={1}
        checkOrientation={false}
        onInitialized={(instance) => {
          setCropper(instance);
        }}
        ref={cropperRef}
      />
      <button onClick={potraitClick}>Potrait</button>
      <button onClick={landscapeClick}>Landscape</button>
      <button onClick={() => setActive(false)}>Cancel</button>
      <button onClick={getCropData}>Save</button>
      <button onClick={onDownload}>Download</button>
    </div>
  );

  const viewEditImage = (id: number) => {
    return (
      <div
        style={{
          width: "10vw",
          // backgroundColor: "rgba(0,0,0,0.7)",
          marginTop: "40px",
          zIndex: "1000",
          position: "relative",
          // left: "calc(-100vw+50%)",
          transform: "translate(-50%, 0%)"
          
        }}
        
      >
        {editId == id &&
          
          (active ? (
            cropperTool()
          ) : (
            <>
              <img
                src={image}
                style={{ width: "40vw", margin: "auto", display: "block" }}
              />
              <button onClick={() => setActive(true)}>Edit</button>
              <button onClick={makeFullScreen}>FS</button>
              <button onClick={() => setEditId(0)}>Cancel</button>
              {/* <button onClick={() => setEditCap(!editCap)}>Edit Caption</button> */}
            </>
          ))}
      </div>
    )
  }

  return (
    <div className="container">
      <Divider />
      <div className="images-list">
      
        {imgObj.map(
          (img, index) =>
            (
              <div className="images-data">
                <img
                  src={img.src}
                  alt="imgs"
                  id="theImage"
                  onClick={() => onImageClick(img.id, img.src)}
                  className={select === img.id ? "img-selected" : "img-view"}
                />
                <span className="number-display ">{index + 1}</span>
                {/* <div className="overlay"></div> */}
                {viewEditImage(img.id)}
              </div>
              
            )
              
        )}
      </div>
      {/* {viewEditImage()} */}
      <div className="box" style={{ width: "50%", float: "left" }}>
        <h1>
        <Tooltip title="Delete">
        <span>Saved Image Preview</span>
        </Tooltip>
          
        </h1>
        <img style={{ width: "100%" }} src={cropData} alt="cropped" />
      </div>
    </div>
  );
};

export default PhotoCropper;
